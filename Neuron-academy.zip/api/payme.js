export default function handler(req, res) {
  if (req.method === "POST") {
    res.status(200).json({ success: true, message: "To'lov qabul qilindi" });
  } else {
    res.status(405).json({ message: "Faqat POST ruxsat etilgan" });
  }
}
