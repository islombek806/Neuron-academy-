export default function Home() {
  return (
    <div>
      <h1>Neuron Academy</h1>
      <p>Sun’iy intellekt kurslari onlayn sotish platformasi.</p>
      <a href="/kurslar">Kurslar ro'yxati</a>
    </div>
  );
}
